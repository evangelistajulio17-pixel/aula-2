# lista-02-udwmj

Lista de Exercícios II – HTML e CSS
Usabilidade, Desenvolvimento Web, Mobile e Jogos – Prof. Daniel Henrique Matos de Paiva

| Pasta | Exercício |
|---|---|
| exercicio-01 | Cartão de Visitas Digital |
| exercicio-02 | Perfil de Personagem |
| exercicio-03 | Receita Simples |
| exercicio-04 | Botão Estilizado |
| exercicio-05 | Card de Notícia |
| exercicio-06 | Tabela de Preços Simples |
| exercicio-07 | Rodapé de Site (Footer) |
